public class CourseWork {
	//variables
	private int sum;
	private int total;
	//functions
	public CourseWork(){
		sum=0;
		total=0;}
	public double average(){
		return sum/(total*100);}
	public void assignment(int ascore){
		if(ascore<0||ascore>100){System.out.println("you have entered an invalid score for Coursework.");}
		else{
		total+=1;
		sum +=ascore;}}
}