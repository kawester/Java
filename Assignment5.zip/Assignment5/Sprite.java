import java.awt.Graphics;
import java.awt.Image;
import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;


class Sprite
{
	private String jpgName;
	private int locationX;
	private int locationY;
	private Image image;

	public Sprite(String jpgName)
	{
		this.jpgName=jpgName;}
	
	public int getX() {	return locationX; }
	public int getY() {	return locationY; }
	
	public void setX(int x) { locationX = x; }
	public void setY(int y) { locationY = y; }
	
	public boolean overlaps(Sprite s){
		if((s.getX()<=getX()+60 && s.getX()+60>getX()) && (s.getY()<=getY()+60 && s.getY()+60>getY()))
			return true;
		else
			return false;}
	
	public void updateState(int x,int y){}
	public void setImage(String imagePath) {
        try {
        	image = ImageIO.read(new File(imagePath));
        } catch (IOException ioe) {
            try {
                image = ImageIO.read(new File("src/"+imagePath));
            } catch (IOException e) {
                System.out.println("Unable to load image file "+imagePath);
            }
        }
	}
	public Image getImage() { return image; }	
	
	public void updateImage(Graphics g) {
		g.drawImage(getImage(), getX(), getY(), 60, 60, null);
	}
}