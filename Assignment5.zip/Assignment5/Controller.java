import java.awt.Graphics;
import java.io.IOException;
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.SwingUtilities;

class Controller implements MouseListener ,KeyListener
{
    Model model;
    View view;

    Controller() throws IOException, Exception {
        model = new Model();
        view = new View(this);
    }

    public void update(Graphics g) {
        model.update(g);
    }

    public void mousePressed(MouseEvent e) {
		if (SwingUtilities.isLeftMouseButton(e)){
			model.make(e.getX(),e.getY());}//makes a new car on left clicks 
		if (SwingUtilities.isRightMouseButton(e)){
			model.updateScene(view.getWidth(),view.getHeight());}//updates model on right clicks 
		view.repaint();}
    
    public void keyPressed (KeyEvent e){
    	char key= e.getKeyChar();
    	Thread t;
    	if(key=='h')
    		System.out.print("hello world");
    	if (key=='s'){
    		t=new Thread(new SpriteMover(model,view));
    		t.start();}
        if (key=='n')
        	model.scoreboard();
        if (key=='r'){
        	model.reset();
        	view.repaint();}}
    
    public void keyreleased (KeyEvent e){}
    public void keyTyped(KeyEvent e){}        		
    public void keyReleased (KeyEvent e){}
    
    public void mouseReleased(MouseEvent e) {    }
    public void mouseEntered(MouseEvent e) {    }
    public void mouseExited(MouseEvent e) {    }
    public void mouseClicked(MouseEvent e) {    }

    public static void main(String[] args) throws Exception {
        new Controller();
    }
}

