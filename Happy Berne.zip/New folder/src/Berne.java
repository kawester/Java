class Berne
{
	int bernex=50;
	int berney;
	int frame=50;
	double vel=.7;
	
	public void update() {
		berney+=vel;
		vel+=.4;
		frame+=1;
	}
	public void Boost(){
		vel=-8.5;
		frame=0;}
	public void setDestination(int x, int y) {
		x=bernex;
		y=berney;}
}