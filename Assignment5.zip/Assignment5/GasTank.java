public class GasTank {
	//class variables
	private int Max;
	private double current;
	//constructor
	GasTank(int m){
		current=0;//sets
		if (m>=0)
			Max=m;
		else
			Max=0;}
	//getters
	public int getCapacity(){return Max;}
	public double getLevel(){return current;}
	//class function
	public void setLevel(double levelIn){		

		if (0<=levelIn & levelIn<=Max)
			current=levelIn;
		if (levelIn>Max)
			current=Max;
		if (0>levelIn)
			current=0.00;}
	
}
