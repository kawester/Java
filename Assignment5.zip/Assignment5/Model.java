import java.awt.Graphics;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

class Model
{
	private boolean i=false;
    private ArrayList<Sprite> sprites=new ArrayList<Sprite>();
    Model() throws IOException {
		Bank Fed=new Bank();
		Fed.setX(300);
		Fed.setY(300);
		sprites.add(Fed);
    }

    public void make(int x, int y){
       	if(i==false ){
    		Sprite cop=new CopCar();
    		cop.setX(x);
    		cop.setY(y);
    		sprites.add(cop);}
    	else{
    		Sprite robber=new RobberCar();
			robber.setX(300);
			robber.setY(300);
			sprites.add(robber);}
       	i=!i;}
    
    public void scoreboard(){
    	Sprite anouncer= sprites.get(0);
    	System.out.println(((Bank)anouncer).getscore(1)+" have escaped and "+((Bank)anouncer).getscore(0)+" have been jailed.");}
    
    public void reset(){
    	i=false;
    	synchronized(sprites){
    	Iterator<Sprite> delete=sprites.iterator();
    	while(delete.hasNext()){
    		Sprite s=delete.next();
    			delete.remove();}}
		Bank Fed=new Bank();
		Fed.setX(300);
		Fed.setY(300);
    	sprites.add(Fed);}
    
    public void updateScene(int x,int y){
    	Sprite Cat;
    	Sprite mouse;
		for(int i=1;i<sprites.size();i++){
			Cat=sprites.get(i);
			if(Cat instanceof CopCar)
				for(int ii=1;ii<sprites.size();ii++){
					mouse=sprites.get(ii);
					if(mouse instanceof RobberCar){
						if(((RobberCar)mouse).isCaptured()==false && (((((mouse.getX()+60) <=x) && ((mouse.getY()+60)<=y)) && (mouse.getX()>0 && mouse.getY()>0))==false)){
							synchronized(sprites){
							Iterator<Sprite> trim=sprites.iterator();
							while(trim.hasNext()){
								Sprite s=trim.next();
								if(s==mouse){
									System.out.println("I'm Free!");
									((Bank)sprites.get(0)).score(1);
									trim.remove();}}}}
						if(Cat.overlaps(mouse)==true)
							if(((RobberCar)mouse).isCaptured()==false){
								((Bank)sprites.get(0)).score(0);
								((RobberCar)mouse).captured();}}}}
	for(int i=0;i<sprites.size();i++)
		sprites.get(i).updateState(x,y);}
    
    public void update(Graphics g) {
		for(int i=0;i<sprites.size();i++)
			sprites.get(i).updateImage(g);
 }}
