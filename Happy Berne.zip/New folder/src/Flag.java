import java.util.Random;

class Flag{
	Random random= new Random();  
	int x=500;
	int y=400;
	boolean up;
	public void update(){
		x-=4;
		if (x<=-150){x=500;}
		if (x>=500){
			up=random.nextBoolean();
			if(up==true){y=random.nextInt(200)-400;}
			else{y=random.nextInt(200)+200;}
		}
	}
}