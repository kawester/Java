import javax.swing.JPanel;
import java.awt.Graphics;
import java.awt.Image;
import javax.imageio.ImageIO;
import java.io.IOException;
import java.awt.Graphics;
import java.io.File;

class View extends JPanel {
	Model model;
	Image Bernie, Bernieup, flagup, flagdown;
	View(Model m) throws IOException {
		this.model = m;
		this.Bernie = ImageIO.read(getClass().getResource("Untitled.png"));
		this.Bernieup=  ImageIO.read(getClass().getResource("Untitled2.png"));
		this.flagup =  ImageIO.read(getClass().getResource("flagup.png"));
		this.flagdown =  ImageIO.read(getClass().getResource("flagdown.png"));
	}

	public void paintComponent(Graphics g) {

		if(this.model.berne.frame>15)
			g.drawImage(this.Bernie, this.model.berne.bernex, this.model.berne.berney, null);
		else
			g.drawImage(this.Bernieup, this.model.berne.bernex, this.model.berne.berney, null);
		if(this.model.flag.up==true){
			g.drawImage(this.flagup, this.model.flag.x, this.model.flag.y, null);}
		else {
			g.drawImage(this.flagdown, this.model.flag.x, this.model.flag.y, null);}
	}
}
