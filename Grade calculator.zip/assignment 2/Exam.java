public class Exam {
	//variables
	private static int score;
	private static char grade;
	public Exam(){
		score=100;
		grade='A';}
	//setters and getters
	public static void setscore (int s){
		if (score<0){score=0;}
		else if (score>100){score=100;}
		else if (score>=0&&score<=100){score=s;}
		else{System.out.println("u fuked up m8");}}
	public static void setgrade(char g){
		if(grade=='A'||grade=='B'||grade=='C'||grade=='D'||grade=='F'){
			grade=g;}
		else{
			System.out.println(g+" is not a valid grade m80!");}}
	public int getscore()
		{return score;}
	public char getgrade()
		{return grade;}
	}