
public class Engine {

	//class variables
	private String type;
	private int mpg;
	private int MaxV;
	//constructor
	Engine(String t,int g,int v){
		//sets
		if (t.length()==0)
			type="Generic Engine";
		else
			type=t;
		if (g<0)
			mpg=0;
		else
			mpg=g;
		if (v<0)
			MaxV=0;
		else
			MaxV=v;
	}
	//getters
	public int mpg(){return mpg;}
	public int MaxV(){return MaxV;}
	public String getDescription(){return type+"(MPG: "+mpg+", Max speed: "+MaxV;}
	
}
