import java.awt.Graphics;
import java.util.Random;

public class CopCar extends Car{
private static int xRatio, yRatio;
private int X,Y;
private static Random rand=new Random();
CopCar(){//constructor
	super("cop-car.jpg");
	fillUp();
	if(rand.nextBoolean())
		xRatio=rand.nextInt(5);
	else
		xRatio=-rand.nextInt(5); 
	if(rand.nextBoolean())
		yRatio=rand.nextInt(5);
	else
		yRatio=-rand.nextInt(5);
	X=xRatio;
	Y=yRatio;}

public void updateState(int x, int y){//Not sure why cars sometimes don't bounce off walls after hitting them
	if ( ((getX()+60) >=x) || getX()<=0){// if the right edge leaves the right side of window or the left edge leaves the left side of the window
		X*=-1;}
	if ( ((getY()+60)>=y) || getY()<=0){// if the bottom edge leaves the bottom of the window or the top leaves the left side of the window
		Y*=-1;}
	drive(2,X,Y);
	super.updateState(x,y);}

public void updateImage(Graphics g) {
	super.updateImage(g);}//draw

}
