//imported classes
import java.awt.Graphics;
import java.math.BigDecimal;
import javax.swing.JOptionPane;

public class Car extends Sprite{
	
	//class variables
	private String description;
	private GasTank tank;
	private Engine engine;
	
	//constructor sets variable instances
	Car(String type){
		super(type);
		setImage(type);
		if (type=="cop-car.jpg"){
			tank=new GasTank(5000);
			engine= new Engine("generic engine",20,200);}
		else if(type=="red-car.jpg"){
			tank=new GasTank(5000);
			engine= new Engine("generic engine",30,100);}
		else
			System.out.print("error1");}

	//getters
	public double getFuelLevel(){return tank.getLevel();}
	public double getMPG(){return tank.getLevel();}
	public int getMaxSpeed(){return engine.MaxV();}                   
	public String getDescription(){
		BigDecimal current=new BigDecimal(tank.getLevel());
		BigDecimal X=new BigDecimal(getX());
		BigDecimal Y=new BigDecimal(getY());
		current=current.setScale(2, BigDecimal.ROUND_HALF_UP);
		X=X.setScale(0, BigDecimal.ROUND_HALF_UP);
		Y=Y.setScale(0, BigDecimal.ROUND_HALF_UP);
		String D=description+" (Engine: "+engine.getDescription()+"), fuel ("+current+"/"+tank.getCapacity()+"), location ("+X+","+Y+")";
	return D;}

	//class functions: fill up and drive,drive,drive...
	public void fillUp(){tank.setLevel(tank.getCapacity());}
	
	public void updateState(int x, int y){super.updateState(x,y);}
	
	public void updateImage(Graphics g) {//zap
		super.updateImage(g);}
	
	public double drive(int distance, double xRatio, double yRatio){
		//local variables
		double maxdistance=(tank.getLevel()*(double)engine.mpg());
		double t=0.00;
		double theta=Math.atan(Math.abs(yRatio)/Math.abs(xRatio));
			
		if(distance<=maxdistance){//you made it
			if (xRatio==0&& getY()!=0)
				setY(getY()+distance);
			if (yRatio==0&&getX()!=0)
				setX(getX()+distance);
			if(xRatio<0&&yRatio>0){
				setY(getY()+(int)(distance*Math.sin(theta)));
				setX(getX()-(int)(distance*Math.cos(theta)));}
			if(xRatio>0&&yRatio<0){
				setY(getY()-(int)(distance*Math.sin(theta)));
				setX(getX()+(int)(distance*Math.cos(theta)));}
			if(xRatio<0 && yRatio<0){//coordinates
				setY(getY()-(int)(distance*Math.sin(theta)));
				setX(getX()-(int)(distance*Math.cos(theta)));}
			if(xRatio>0&& yRatio>0){
				setY(getY()+(int)(distance*Math.sin(theta)));
				setX(getX()+(int)(distance*Math.cos(theta)));}
			
			t=(tank.getLevel()-((double)distance/(double)engine.mpg()));
			BigDecimal X=new BigDecimal(getX());//precision
			BigDecimal Y=new BigDecimal(getY());
			X=X.setScale(0, BigDecimal.ROUND_HALF_UP);
			Y=Y.setScale(0, BigDecimal.ROUND_HALF_UP);
			tank.setLevel(t);//uses gas
			return distance;}
	
		if (distance>maxdistance){//you ran out of gas
			if (xRatio==0)
				setY(getY()+(int)maxdistance);
			if (yRatio==0)
				setX(getX()+(int)maxdistance);
			if(xRatio<0&&yRatio>0){
				setY(getY()+(int)(maxdistance*Math.sin(theta)));
				setX(getX()-(int)(maxdistance*Math.cos(theta)));}
			if(xRatio>0&&yRatio<0){
				setY(getY()-(int)(maxdistance*Math.sin(theta)));
				setX(getX()+(int)(maxdistance*Math.cos(theta)));}
			if(xRatio<0 && yRatio<0){//coordinates
				setY(getY()-(int)(maxdistance*Math.sin(theta)));
				setX(getX()-(int)(maxdistance*Math.cos(theta)));}
			if(xRatio>0 && yRatio>0){
				setY(getY()+(int)(maxdistance*Math.sin(theta)));
				setX(getX()+(int)(maxdistance*Math.cos(theta)));}

			t=(tank.getLevel()-((double)maxdistance/(double)engine.mpg()));
			tank.setLevel(t);
			return maxdistance;}
	
		if (distance<=0){//you didn't go anywhere
			return 0;}
	
		//just in case
		JOptionPane.showMessageDialog(null,"error");
		return 0;}

}
