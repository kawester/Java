import java.awt.Graphics;

public class Bank extends Sprite{
private int injail,escaped;
Bank(){
	super("bank.png");
	setImage("bank.png");}//constructor 

public void score(int i){
	if (i==0)
		injail++;
	if (i==1)
		escaped++;
}

public int getscore(int i){
	if (i==0)
		return injail;
	if (i==1)
		return escaped;
	else
		return -1;}

public void updateImage(Graphics g){super.updateImage(g);}//The bank never does anything for the State.
}