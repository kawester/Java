class Model {
	Berne berne;
	Flag flag;
	boolean collision=false;
	Model() {
		berne=new Berne();
		flag=new Flag();
		flag.x=501;
	}
	public void Boost() {this.berne.Boost();}	
	public void update(){
		berne.update();
		flag.update();
		if(flag.up==false){
			if((this.berne.bernex+84) > this.flag.x && this.berne.bernex < (this.flag.x+145) && this.berne.berney+90 > this.flag.y)
				System.out.println("collision (down)");
				collision=true;}
		else
			if((this.berne.bernex+84) > this.flag.x && this.berne.bernex < (this.flag.x+145) && this.berne.berney < this.flag.y+498){
				collision=true;
				System.out.println("collision(up)");}
		if (collision==true){
			collision=false; }
	}	
	public void setDestination(int x, int y) {
		x=berne.bernex;
		y=berne.berney;
	}
} 