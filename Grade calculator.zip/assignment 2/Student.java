
public class Student {
	//variable declarations
	private static String firstname;
	private static String lastname;
	private Exam Midterm= new Exam();
	private Exam Final=new Exam();
	private CourseWork Activities= new CourseWork();
	private CourseWork homework= new CourseWork();
	//constructor and methods
	public Student(String first, String last){
		firstname=first;
		lastname=last;}
	public void setMidterm(int mscore, char mgrade){
		Midterm.setgrade(mgrade);
		Midterm.setscore(mscore);}
	public void setFinal(int fscore, char fgrade){
		Final.setgrade(fgrade);
		Final.setscore(fscore);}
	public void addGradedHomework(int hscore){
		homework.assignment(hscore);}
	public void addGradedActivity(int ascore){
		Activities.assignment(ascore);}
	public void printGrade(){//prints the students final class grade according to the scale or matches it to their lowest exam grade. The student will be given the highest grade of the two options.
		double score;
		char grade;
		if (((Midterm.getscore()*.25)+(Final.getscore()*.35)+(Activities.average()*.15)+(homework.average()*.25))<Final.getscore()||((Midterm.getscore()*.25)+(Final.getscore()*.35)+(Activities.average()*.15)+(homework.average()*.25))<Midterm.getscore()){
			if(Final.getscore()<Midterm.getscore()){
				score=Final.getscore();}//final is higher than normal scale but less than Midterm 
			else{
				score=Midterm.getscore();}}//Midterm is higher than normal scale but less than Final
		score=(Midterm.getscore()*.25)+(Final.getscore()*.35)+(Activities.average()*.15)+(homework.average()*.25);//scale grade
		if(score<60){grade='F';}
		else if(score<70){grade='D';}
		else if(score<80){grade='C';}
		else if(score<90){grade='B';}
		else{grade='A';}
	System.out.println("Final course grade for "+Student.firstname+" "+Student.lastname+" "+grade+" "+score+"%");}
//end of student class definitions		
	
	
	
//main program	
	public static void main(String args[])
	{
		Student s1 = new Student("Matt", "Patitz");
		s1.setMidterm(78, 'B');
		s1.setFinal(70, 'C');
		s1.addGradedHomework(90);
		s1.addGradedHomework(95);
		
		s1.addGradedActivity(100);
		s1.addGradedActivity(70);
		s1.printGrade();
		

		s1 = new Student("John", "Johnson");
		s1.setMidterm(90, 'B');
		s1.setFinal(70, 'B');
		s1.addGradedHomework(60);
		s1.addGradedHomework(70);
		s1.addGradedHomework(40);
		
		s1.addGradedActivity(80);
		s1.addGradedActivity(50);
		s1.printGrade();
		
		
		s1 = new Student("Foo", "Fooson");
		s1.setMidterm(60, 'G');
		s1.setFinal(70, 'B');
		s1.addGradedHomework(60);
		s1.addGradedHomework(70);
		s1.addGradedHomework(40);
		
		s1.addGradedActivity(80);
		s1.addGradedActivity(50);
		s1.printGrade();
		
		
		s1 = new Student("Fake", "Student");
		s1.setMidterm(90, 'B');
		s1.setFinal(70, 'B');
		s1.addGradedHomework(-30);
		s1.addGradedHomework(70);
		s1.addGradedHomework(40);
		
		s1.addGradedActivity(110);
		s1.addGradedActivity(50);
		s1.printGrade();
	}
}
