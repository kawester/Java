import java.awt.Graphics;
import java.util.Random;

public class RobberCar extends Car{
private int xRatio;
private int yRatio;
private boolean jailed=false;
private static Random rand=new Random();
RobberCar(){//constructor
	super("red-car.jpg");
	fillUp();
	if(rand.nextBoolean())
		xRatio=rand.nextInt(5);
	else
		xRatio=-rand.nextInt(5);
	if(rand.nextBoolean())
		yRatio=rand.nextInt(5);
	else
		yRatio-=rand.nextInt(5);}

public void captured(){
	jailed=true;
	System.out.println("Gotcha!");
	setImage("jail.jpg");}

public boolean isCaptured(){
	if(jailed==true)
		return true;
	else
		return false;}

public void updateState(int x, int y){
	if(isCaptured()==false)	
		drive(4,xRatio,yRatio);
	super.updateState(x,y);}

public void updateImage(Graphics g){   
	super.updateImage(g);}//draw

}
