
public class SpriteMover implements Runnable{
	private Model M;
	private View V;
	SpriteMover(Model m, View v){
		M=m;
		V=v;
	}
	
	public void run() {
	    while (true) {
			M.updateScene(V.getWidth(),V.getHeight());
			V.repaint();
	        try {
	            Thread.sleep(2);
	        } catch (InterruptedException e) {}
	    }}
}